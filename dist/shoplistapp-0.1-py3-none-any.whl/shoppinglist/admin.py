from django.contrib import admin
from shoppinglist.models import Shoppinglist

admin.site.register(Shoppinglist)
